/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mavenproject1;

import model.Cliente;
import model.Movimentacao;

/**
 *
 * @author nandi
 */
public class main {
    public static void main(String[] args) {
    Cliente c1 = new Cliente("Luiz", "2000");
    c1.setSaldo(500);
    
    Movimentacao m1 = new Movimentacao(c1);
    
    m1.sacarDinheiro(250.00);
    
    }
    
            
}
