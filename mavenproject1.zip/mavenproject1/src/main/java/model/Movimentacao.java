package model;

import java.time.Clock;

public class Movimentacao {
    private Cliente cliente;
    private double valor;
    private int ced100;
    private int ced50;
    private int ced20;
    private int ced10;
    private int ced5;
    private int ced2;
    private int ced1;
    private int ced050;
    private int ced025;
    private int ced010;
    private int ced05;
    private int ced01;

    public Movimentacao(Cliente cliente) {
        this.cliente = cliente;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }
    
  public void sacarDinheiro(double valor)
  {
   ced100 = 0;  
   ced50 = 0;
   ced20= 0;
   ced10= 0;
   ced5 = 0;
   ced2 = 0;
   ced1 = 0;
   ced050 = 0;
   ced025 = 0;
   ced010 = 0;
   ced05= 0;
   ced01= 0;
      if(cliente.getSaldo()>=valor)
      {
          while(valor > 0)
          {
            if(valor>100.00)
            {
                ced100+=1;
                break;
            } else if(valor>50.00)
            {
                ced50+=1;
                break;
            } else if(valor>20.00)
            {
                ced20+=1;
                break;
            } else if(valor>10.00)
            {
                ced10+=1;
                break;
            } else if(valor>5.00)
            {
                ced5+=1;
                break;
            } else if(valor>2.00)
            {
                ced2+=1;
                break;
            }
            else if(valor>1.00)
            {
                ced1+=1;
                break;
            } else if(valor>0.50)
            {
                ced050+=1;
                break;
            } else if(valor>0.25)
            {
                ced025+=1;
                break;
            } else if(valor>0.10)
            {
                ced010+=1;
                break;
            } else if(valor>0.05)
            {
                ced05+=1;
                break;
            } else if(valor>0.01)
            {
                ced01+=1;
                break;
            } else System.out.println("TOTAL DE CEDULAS A REGASTAR: \n"
                    + "NOTAS DE R$ 100.00: " + ced100 + "\n"
                    + "NOTAS DE R$ 50.00: " + ced50 + "\n"
                    + "NOTAS DE R$ 20.00: " + ced20 + "\n"
                    + "NOTAS DE R$ 10.00: " + ced10 + "\n"
                    + "NOTAS DE R$ 5.00: " + ced5 + "\n"
                    + "NOTAS DE R$ 2.00: " + ced2 + "\n"
                    + "MOEDAS DE R$ 1.00: " + ced1 + "\n"
                    + "MOEDAS DE R$ 0.50: " + ced050 + "\n"
                    + "MOEDAS DE R$ 0.25: " + ced025 + "\n"
                    + "MOEDAS DE R$ 0.10: " + ced010 + "\n"
                    + "MOEDAS DE R$ 0.05: " + ced05 + "\n"
                    + "MOEDAS DE R$ 0.01: " + ced01 + "\n"
                    
            );
              
          }
      } else System.out.println("SALDO INSULFICIENTE");
  }
    
}
